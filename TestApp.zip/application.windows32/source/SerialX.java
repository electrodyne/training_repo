import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.serial.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SerialX extends PApplet {

/**
 * Serial Duplex 
 * by Tom Igoe. 
 * 
 * Sends a byte out the serial port when you type a key
 * listens for bytes received, and displays their value. 
 * This is just a quick application for testing serial data
 * in both directions. 
 */




Serial myPort;      // The serial port
int whichKey = -1;  // Variable to hold keystoke values
int inByte = -1;    // Incoming serial data
boolean isSerialSelected = false;
int str1XOffset = 15;
String userString = "";
int pageIndex = 0;

//debug vars
int stringlength = 0;
String usrStr = "-1";
String lastSent = "-1";
long counter1 = 0;
long previousMillis = 0;

String replyPacket = "OK";  // a reply string to send back
int counter = 0;

public void setup() {
  
  // create a font with the third font available to the system:
//  printArray(PFont.list());
  PFont myFont = createFont("Courier New", 14);
  textFont(myFont);

  // List all the available serial ports:
  //printArray(Serial.list());

  // I know that the first port in the serial list on my mac
  // is always my  FTDI adaptor, so I open Serial.list()[0].
  // In Windows, this usually opens COM1.
  // Open whatever port is the one you're using.
  //String portName = Serial.list()[0];
  //String portName = "COM15";
  //myPort = new Serial(this, portName, 115200); //<>//
  previousMillis = millis();
  counter1 = millis();
}

public void draw() {
  
  background(0);
   
  if(isSerialSelected){
  text("Send from mobile first. ", 10, 50);  
  text("The Device is acting as a server, which needs client..", 10, 65);
  text("Reply within 10s after sending from App.", 10, 80);
  text("Last Received: " + usrStr, 10, 135);
//  text("Last Sent: " + lastSent, 10, 120);
  //text(userString, 10,161);
/*  if ( millis() - counter1 > 1000){
    text("Enter Text: " + userString, 10, 150);
    counter1 = millis();
  } else if ( millis() - counter1 < 500) {
    text("Enter Text: " + userString+"|", 10, 150);
  } else {
    text("Enter Text: " + userString, 10, 150);
  }
  */
  } else {
    text("Select Port Num: ", 10, 110);
    for(pageIndex = 0; pageIndex < Serial.list().length; pageIndex++) {
      text('[' + Integer.toString(pageIndex) + ']', str1XOffset,130+(20*pageIndex));
      text(Serial.list()[pageIndex],40+str1XOffset,130+(20*pageIndex));
    } 
  }
}

public void serialEvent(Serial myPort) {
  if (millis() - previousMillis > 50) {
    //this proves that a new set of data has arrived.
    //clear the usrStr memory.
    usrStr = "";
  }
  inByte = myPort.read();
  if ( inByte == '\n' ) 
  {
    for ( int j = 0 ; j < replyPacket.length(); j++ ) 
    {
       myPort.write(replyPacket.charAt(j));
       
    }
    counter++;
     
    for ( int k = 0; k < Integer.valueOf(counter).toString().length(); k++ )
    {
      myPort.write(Integer.valueOf(counter).toString().charAt(k));
    }
    
  } else 
  {
    usrStr += (char)inByte;
  }
  //myPort.write(inByte);
  previousMillis = millis();
  //millis()-previousMillis = time elapsed after the previous event. ~50ms
}

public void keyPressed() {
  // Send the keystroke out:
  //if( isSerialSelected )
   // myPort.write(key);
  //whichKey = key; //ASCII key is inside 'whichKey' variable.
  //println(Integer.toString(key));
 
  
  if ( key == 10 ) {
    /*
    usrStr = userString;
    print(usrStr);
    stringlength = userString.length();
    print(stringlength);
    */
     
    
    if (isSerialSelected) {
      //enter has been pressed. send the data to myPort
      for ( int j = 0 ; j < userString.length(); j++ ) {
    //  for ( int j = 0 ; j < replyPacket.length(); j++ ) {
        myPort.write(userString.charAt(j));
    //   myPort.write(replyPacket.charAt(j));
      }
      //reflect at Last Sent.
      lastSent = userString;
      //clear userString.
      userString = "";
    } else {
      byte[] byteStr = userString.getBytes();
      if (byteStr.length  == 1 && byteStr[0] > 47 && byteStr[0] < 58) {
        myPort = new Serial(this, Serial.list()[Integer.parseInt(userString)], 115200);
        println("OK");
        isSerialSelected = true;
        userString = "";
      } else
        userString = "";
    }
    
    
    //convert string to integer equivalent
     //<>//
    
    
    
  }
  else if (key == 8){
    if ( userString.length() > 0) {
      userString = userString.substring(0,userString.length() - 1);
    }
  }
  else {
    userString += (char)key;
  }
  
  
  
}
  public void settings() {  size(500, 300); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SerialX" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
